
from flask import Flask, render_template, request, redirect, url_for, flash
import pymysql

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Database Configuration
conn = pymysql.connect(host='localhost', user='root', password='srushti', database='student_management')

# Ensure trigger exists for preventing duplicate roll numbers on INSERT
with conn.cursor() as cursor:
    trigger_query = """
    CREATE TRIGGER prevent_duplicate_rollno_insert
    BEFORE INSERT ON students
    FOR EACH ROW
    BEGIN
        DECLARE roll_exists INT;

        SELECT COUNT(*) INTO roll_exists FROM students WHERE roll_no = NEW.roll_no;

        IF roll_exists > 0 THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Roll number already exists!';
        END IF;
    END;
    """
# If roll_exists > 0, it means a student with the same roll_no already exists in the database.
# The SIGNAL SQLSTATE '45000' statement raises an error and prevents the insertion.
# '45000' is a generic SQLSTATE error code for custom application errors.


    try:
        cursor.execute(trigger_query)
        conn.commit()
    except pymysql.err.OperationalError:
        pass  # Trigger already exists

# Ensure trigger exists for preventing duplicate roll numbers on UPDATE
with conn.cursor() as cursor:
    trigger_query = """
    CREATE TRIGGER prevent_duplicate_rollno_update
    BEFORE UPDATE ON students
    FOR EACH ROW
    BEGIN
        DECLARE roll_exists INT;

        SELECT COUNT(*) INTO roll_exists FROM students WHERE roll_no = NEW.roll_no AND id != NEW.id;

        IF roll_exists > 0 THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Roll number already exists!';
        END IF;
    END;
    """
    try:
        cursor.execute(trigger_query)
        conn.commit()
    except pymysql.err.OperationalError:
        pass  # Trigger already exists


@app.route('/')
def index():
    """
    Handles the homepage, displaying a list of students with search and sorting functionality.
    """

    # Retrieve query parameters from the URL
    search_query = request.args.get('search', '')  # Get the search query (default: empty)
    sort_by = request.args.get('sort_by', 'id')    # Get sorting column (default: 'id')
    order = request.args.get('order', 'ASC')       # Get sorting order (default: 'ASC')

    # Ensure sorting is only allowed on specific columns to prevent SQL injection
    valid_columns = {'name', 'roll_no', 'id'}
    if sort_by not in valid_columns:
        sort_by = 'id'  # Default to sorting by 'id' if invalid column is provided
    
    # Ensure order is either 'ASC' or 'DESC' (default to 'ASC')
    order = 'ASC' if order.upper() == 'ASC' else 'DESC'

    # Base SQL query to fetch student details
    query = """
    SELECT students.id, students.name, students.roll_no, students.email, students.program
    FROM students
    """

    # If search query is provided, filter by student name
    if search_query:
        query += " WHERE students.name LIKE %s"
        query += f" ORDER BY {sort_by} {order}"
        with conn.cursor() as cursor:
            cursor.execute(query, ('%' + search_query + '%',))  # Use parameterized query
        


    else:
        # If no search query, just order results
        query += f" ORDER BY {sort_by} {order}"
        with conn.cursor() as cursor:
            cursor.execute(query)

    # Fetch results from the database
    students = cursor.fetchall()

    # Render the template and pass retrieved data
    return render_template('index.html', students=students, search_query=search_query, sort_by=sort_by, order=order)



@app.route('/student/<int:id>')
def student_details(id):
    """
    Fetches details for a specific student, including their enrolled courses, grades, and attendance.
    Also calculates the total number of courses and average attendance percentage.
    """

    # Query to fetch student details along with their courses, grades, and attendance
    
# Includes the student even if they have no enrollments.
# If the student is not enrolled, course_name and grade will be NULL (handled by COALESCE).


    query = """
   SELECT
    students.name,
    students.roll_no,
    students.email,
    courses.course_name,
    COALESCE(enrollments.grade, 'N/A') AS grade,  -- If grade is NULL, return 'N/A'
    COALESCE(enrollments.attendance, 'N/A') AS attendance,  -- If attendance is NULL, return 'N/A'
    enrollments.id AS enrollment_id
   FROM students
   LEFT JOIN enrollments ON students.id = enrollments.student_id
   LEFT JOIN courses ON enrollments.course_id = courses.id
   WHERE students.id = %s
    """

    # Execute query and fetch student data
    with conn.cursor() as cursor:
        cursor.execute(query, (id,))
        student_courses = cursor.fetchall()  # List of all courses the student is enrolled in

    # Calculate total courses enrolled
    total_courses = len(student_courses)

    # Calculate average attendance percentage
    if total_courses > 0:
        avg_percentage_query = """
        SELECT AVG(attendance) 
        FROM enrollments 
        WHERE student_id = %s
        """
        with conn.cursor() as cursor:
            cursor.execute(avg_percentage_query, (id,))
            avg_percentage = cursor.fetchone()[0] or 0  # Handle None case to avoid errors
    else:
        avg_percentage = 0  # If no courses, attendance is 0

    # Render the student details page with all retrieved data
    return render_template('student_details.html',
                           student_courses=student_courses,
                           total_courses=total_courses,
                           avg_percentage=round(avg_percentage, 2),  # Round to 2 decimal places
                           student_id=id)



@app.route('/edit_enrollment/<int:enrollment_id>', methods=['GET', 'POST'])
def edit_enrollment(enrollment_id):
    query = "SELECT student_id, course_id, grade, attendance FROM enrollments WHERE id = %s"
    with conn.cursor() as cursor:
        cursor.execute(query, (enrollment_id,))
        enrollment = cursor.fetchone()

    if enrollment is None:
        flash('Enrollment not found.', 'danger')
        return redirect(url_for('index'))  # Or some appropriate error handling

    student_id = enrollment[0]  # Extract student_id for redirection

    if request.method == 'POST':
        grade = request.form['grade']
        attendance = request.form['attendance']

        update_query = "UPDATE enrollments SET grade = %s, attendance = %s WHERE id = %s"
        try:
            with conn.cursor() as cursor:
                cursor.execute(update_query, (grade, attendance, enrollment_id))
                conn.commit()
            flash('Enrollment updated successfully!', 'success')
            return redirect(url_for('student_details', id=student_id))  # Redirect back to the student details page

        except pymysql.MySQLError as e:
            flash(f'Error updating enrollment: {e}', 'danger')
            return redirect(url_for('student_details', id=student_id))

    # Render a form to edit the enrollment (you'll need to create this template)
    return render_template('edit_enrollment.html', enrollment=enrollment, enrollment_id=enrollment_id,
                           student_id=student_id)


@app.route('/delete_enrollment/<int:enrollment_id>')
def delete_enrollment(enrollment_id):
    # Fetch student_id before deleting
    query = "SELECT student_id FROM enrollments WHERE id = %s"
    with conn.cursor() as cursor:
        cursor.execute(query, (enrollment_id,))
        enrollment = cursor.fetchone()

    if enrollment is None:
        flash('Enrollment not found.', 'danger')
        return redirect(url_for('index'))

    student_id = enrollment[0]  # Get the student ID

    delete_query = "DELETE FROM enrollments WHERE id = %s"
    try:
        with conn.cursor() as cursor:
            cursor.execute(delete_query, (enrollment_id,))
            conn.commit()
        flash('Enrollment deleted successfully!', 'success')
    except pymysql.MySQLError as e:
        flash(f'Error deleting enrollment: {e}', 'danger')

    return redirect(url_for('student_details', id=student_id))


@app.route('/add', methods=['GET', 'POST'])
def add_student():
    if request.method == 'POST':
        name = request.form['name']
        roll_no = request.form['roll_no']
        email = request.form['email']
        program = request.form['program']

        try:
            with conn.cursor() as cursor:
                cursor.execute("INSERT INTO students (name, roll_no, email, program) VALUES (%s, %s, %s, %s)",
                               (name, roll_no, email, program))
                conn.commit()
            flash('Student Added Successfully!', 'success')
        except pymysql.MySQLError as e:
            flash('Error: ' + str(e), 'danger')

        return redirect(url_for('index'))

    return render_template('add_student.html')


@app.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit_student(id):
    with conn.cursor() as cursor:
        cursor.execute("SELECT * FROM students WHERE id = %s", (id,))
        student = cursor.fetchone()

    if request.method == 'POST':
        name = request.form['name']
        roll_no = request.form['roll_no']
        email = request.form['email']
        program = request.form['program']

        try:
            with conn.cursor() as cursor:
                cursor.execute("UPDATE students SET name = %s, roll_no = %s, email = %s, program = %s WHERE id = %s",
                               (name, roll_no, email, program, id))
                conn.commit()
            flash('Student Updated Successfully!', 'success')
        except pymysql.MySQLError as e:
            flash('Error: ' + str(e), 'danger')
            return render_template('edit_student.html', student=student, error=str(e)) # Render the template again with the error message

        return redirect(url_for('index'))

    return render_template('edit_student.html', student=student)


@app.route('/delete/<int:id>')
def delete_student(id):
    with conn.cursor() as cursor:
        cursor.execute("DELETE FROM students WHERE id = %s", (id,))
        conn.commit()
    flash('Student Deleted Successfully!', 'success')
    return redirect(url_for('index'))


if __name__ == '__main__':
    app.run(debug=True)
