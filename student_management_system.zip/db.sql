-- Create Database
CREATE DATABASE student_management;
USE student_management;

-- Create Students Table
CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    roll_no INT,
    email VARCHAR(100),
    program VARCHAR(255)
);

-- Create Courses Table
CREATE TABLE courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_name VARCHAR(255) NOT NULL
);

-- Create Enrollments Table (Linking Students and Courses)
CREATE TABLE enrollments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    course_id INT,
    grade VARCHAR(10),
    attendance INT,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

-- Trigger to Prevent Duplicate Roll Numbers on INSERT
DELIMITER //
CREATE TRIGGER prevent_duplicate_rollno_insert
BEFORE INSERT ON students
FOR EACH ROW
BEGIN
    DECLARE roll_exists INT;
    SELECT COUNT(*) INTO roll_exists FROM students WHERE roll_no = NEW.roll_no;
    IF roll_exists > 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Error: Roll number already exists!';
    END IF;
END;
//
DELIMITER ;


-- Trigger to Prevent Duplicate Roll Numbers on UPDATE
DELIMITER //
CREATE TRIGGER prevent_duplicate_rollno_update
BEFORE UPDATE ON students
FOR EACH ROW
BEGIN
    DECLARE roll_exists INT;
    SELECT COUNT(*) INTO roll_exists FROM students WHERE roll_no = NEW.roll_no AND id != NEW.id;
    IF roll_exists > 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Error: Roll number already exists!';
    END IF;
END;
//
DELIMITER ;

-- COUNT(*) does not always return 1 in the INSERT trigger, 
-- -- but it would always return 1 in the UPDATE trigger if we didn't exclude id != NEW.id
-- -- for update the row already exists thus we must exclude it, for insert the row is not yet added 
-- so the check becomes unnecessary

-- MVC ARCHITECTURE
-- Model (M)	MySQL Database, students,courses & enrollments tables, queries using pymysql, 
-- triggers for data validation.
-- -- View (V)	HTML templates (index.html, student_details.html, add_student.html, etc.),
--  for dynamic rendering. [user interface]
-- -- Controller (C)	Flask routes (@app.route functions) handle requests, interact with the database,
--  and render templates. [bridge between view and model]



-- Metadata is simply defined as data about data. It means it is a description and context of the data. It helps to organize, find and understand data. Let me explain to you by giving a real-world example of metadata: 

-- Every time you take a photo with today’s cameras a bunch of metadata is gathered and saved with it. Such as

-- File name,
-- Size of the file,
-- Date and time,
-- Camera settings etc.
-- Meta data in Relational database: 
-- Relational databases store and provide access not only to data but also metadata in a structure 
-- called data dictionary or system catalog. It holds information about:

-- tables,
-- columns,
-- data types,
-- table relationship,
-- constraints etc.


-- Data dictionary:

-- A data dictionary is a collection of descriptions of the data objects or items in a data model for 
-- the benefit of programmers and others who need to refer to them.
-- -- A data dictionary contains a list of all files in the database, the number of records in each file,
--  and the names and types of each field. Most database management systems keep the data dictionary hidden 
--  from users to prevent them from accidentally destroying its contents.


-- How HTTP works
-- A client makes a request to a server. 
-- The server responds with the requested content and information about the request. 
-- HTTP is stateless, meaning the server doesn't save session data between requests. 
-- HTTP is textual, meaning all communication is in plain text. 